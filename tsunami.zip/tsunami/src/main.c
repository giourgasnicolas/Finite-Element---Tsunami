# include "tsunami.h"

int main(void)
{   
        char *meshName = "../data/PacificTiny.txt";
        char *resultBaseName = "output/tsunamiTiny";
        tsunamiCompute(20,400,100,meshName,resultBaseName); //T'augmente le pas de temps si tu prends un maillage plus grossier  2 pour fine 20 pour Tiny
        tsunamiAnimate(20,400,100,meshName,resultBaseName);
        exit(0);     
}
